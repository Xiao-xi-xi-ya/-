#ifndef __PID_PHASE_H
#define __PID_PHASE_H
#include "sys.h"


void get_phaseV(float * vot, uint8_t chnum, u8 times);
u32 get_deltV(u8 times,u8 sample_num,u8 delay_time);


#endif

