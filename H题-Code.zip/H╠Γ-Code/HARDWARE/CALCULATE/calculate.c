
#include "calculate.h" 
#include "adc_dma_timer.h"
#include "stm32f4xx.h"                  // Device header

#include "stdio.h"
#include "delay.h"
#include "usart.h"


/*
1-500kHz

*/

u8 dipin=0;
u8 flag=0;

extern u8  TIM5CH2_CAPTURE_STA;		//���벶��״̬		    				
extern u32	TIM5CH2_CAPTURE_VAL;	//���벶��ֵ  
extern u32 TIM_ExtCntFreq;

void adjust(u32 f)
{
	
	u32 arrr=f*64;	//��Ӧ�Ĳ���Ƶ�ʣ�һ������size/2����
//	//f=200000;
//	printf("����Ƶ�ʣ�%ld\r\n",f);
	
		if((f*64)>640000+1)
		{
			printf("��Ч\r\n");
			
			arrr=f/(64+1)*64;
			
		}
//		arrr=640000;
//		printf("%ld\r\n",(int)arrr);
		TIM3_Config(arrr);
		delay_ms(50);
		
}


u32 test_f(void)
{
	u8 i=0;
	u32 temp_f=0;	
			
			TIM_ClearFlag(TIM4,TIM_IT_Update);		//ֻ��2 5������ʮ��λ
			TIM4->PSC = 10-1;
			TIM_Cmd(TIM4, ENABLE);
			delay_ms(500);
			
			for(i=0;i<10;i++)
			{
					while(flag==0);
					printf("%3.3lf*100kHz\n",(double)TIM_ExtCntFreq/1000.00f);
					delay_ms(10);
					flag=0;
					if(TIM_GetITStatus(TIM4,TIM_IT_Update))
					{
							printf("�����\r\n");
							printf("����6M\r\n");
							TIM_ClearFlag(TIM4,TIM_IT_Update);
							TIM4->PSC = 100-1;
							delay_ms(10);
							dipin=2;
						break;
						
					}
				if(i==9)
				{
						if(TIM_ExtCntFreq<10)
						{printf("С��1k\r\n");
							dipin=1;
						}
						
				}
				if(i>1)
					temp_f+=TIM_ExtCntFreq;
				
			}
					temp_f*=12.5;
			
			if(dipin==2)//���ߣ���pre
			{
				temp_f=0;
					for(i=0;i<10;i++)
				{
					while(flag==0);
					printf("%3.3lf MHz\n",(double)TIM_ExtCntFreq/1000.00f);
					delay_ms(10);
					flag=0;
					if(i>1)
					temp_f+=TIM_ExtCntFreq;
					
				}
					TIM4->PSC = 10-1;//�Ļ�ȥ
				dipin=0;
				temp_f*=125;
			}
				
			
			TIM_Cmd(TIM4, DISABLE);
			
			
return temp_f;

}



/*
 * ��ʾ��ͬʱ�ҳ����ֵ����Сֵ
 * �����㷨ӦΪ���η� ʱ�临�Ӷ� O(3/2n)
 */

/* �ҳ���Сֵλ�� */
u16 Min_Float(float Mag[], u16 len)
{
    u16 i, Fn_Num;
    Fn_Num = 0;
    Mag[Fn_Num] = Mag[0];
    for (i = 1; i < len; i++)
    {
        if (Mag[Fn_Num] > Mag[i])
        {
            Fn_Num = i;
        }
    }
    return Fn_Num;
}

/* �ҳ������ڶ�Сֵλ�� */
u16 Min_Unsigned(u16 Mag[], u16 len)
{
    u16 i, Fn_Num;
    Fn_Num = 0;
    Mag[Fn_Num] = Mag[0];
    for (i = 1; i < len; i++)
    {
        if (Mag[Fn_Num] > Mag[i])
        {
            Fn_Num = i;
        }
    }
    return Fn_Num;
}

/* �ҳ����ֵλ�� */
u16 Max_Unsigned(u16 Mag[], u16 len)
{
    u16 i, Fn_Num;
    Fn_Num = 0;
    Mag[Fn_Num] = Mag[0];
    for (i = 1; i < len; i++)
    {
        if (Mag[Fn_Num] < Mag[i])
        {
            Fn_Num = i;
        }
    }
    return Fn_Num;
}

/* ��һ����Χ���ҳ����ֵλ�� */
u16 Max_Float_WithinRange(float Data[], u16 Left, u16 Right)
{
    u16 i, MaxIndex;
    MaxIndex = Left;
    for (i = Left; i <= Right; ++i)
    {
        if (Data[MaxIndex] < Data[i])
        {
            MaxIndex = i;
        }
    }
    return MaxIndex;
}

/*	������		*/
u16 Most_Unsigned(u16 Mag[], u16 len)
{
		u16 i,j,x,m;
	
		u16 buff[10];
		for(i=0;i<len;i++)
	{
			for(j=i+1,x=0;j<len;j++)
		{
				if(Mag[i]==Mag[j])
					x++;
		}
		buff[i]=x;
	}
	
    for(i=0,x=0,m=Mag[0]; i<len; i++)
	{
        if(buff[i]>x){
            x=buff[i];
            m=Mag[i];
        }
        else if(buff[i]==x){
        m=Mag[i]<m?Mag[i]:m;
        }
    }	
	
	
    return m;
}

/*	�жϲ��μ���Ƶ		*/
// wave����0	����1
void Demultiplex(float Mag[], u16 Wave_Type[], u32 Basic_Freq[], u16 len, u32 disting_freq)
{
	u16 Index[2] = {0, 0};
	u16 ind;
	
	float Max_Amp, Second_Amp;
	float Three_Max_Amp, Three_Second_Amp;
	float  Five_Second_Amp;
	float Max_d, Second_d;
	
	Max_SecondMax_Index(Mag, Index, 1, len);

	if(Index[0] < Index[1])
	{
		ind = Index[0];
		Index[0] = Index[1];
		Index[1] = ind;
	}
	//printf("%d,%d\r\n",Index[0],Index[1]);	
	
	Max_Amp = Mag[Index[0]];
	
	Three_Max_Amp = Mag[ Max_Float_WithinRange(Mag, 3*Index[0] - 3, 3*Index[0] + 3) ];
	
	Max_d = Max_Amp / Three_Max_Amp;
	
	if(Max_d > 30.0f) //have sin
	{
		if(Index[1] * 3 != Index[0]) //no cover
		{
			Second_Amp = Mag[Index[1]];
			Three_Second_Amp = Mag[ Max_Float_WithinRange(Mag, 3*Index[1] - 3, 3*Index[1] + 3) ];
			Second_d = Second_Amp / Three_Second_Amp;
				//printf("second:%f\r\n",Second_d);
			if(Second_d < 17.0f) //have tri
			{
				//printf("����");
				Wave_Type[0] = 1;
				Wave_Type[1] = 0;
				Basic_Freq[0] = disting_freq * Index[1] / 1024;
				Basic_Freq[1] = disting_freq * Index[0] / 1024;
			}
			else
			{
				Wave_Type[0] = 0;
				Wave_Type[1] = 0;
				Basic_Freq[0] = disting_freq * Index[1] / 1024;
				Basic_Freq[1] = disting_freq * Index[0] / 1024;
			}
		}
		else
		{
			Second_Amp = Mag[Index[1]];
			Five_Second_Amp = Mag[ Max_Float_WithinRange(Mag, 5*Index[1] - 3, 5*Index[1] + 3) ];
			Second_d = Second_Amp / Five_Second_Amp;
			
			if(Second_d < 40.0f) //have tri
			{
				Wave_Type[0] = 1;
				Wave_Type[1] = 0;
				Basic_Freq[0] = disting_freq * Index[1] / 1024;
				Basic_Freq[1] = disting_freq * Index[0] / 1024;
			}
			else
			{
				Wave_Type[0] = 0;
				Wave_Type[1] = 0;
				Basic_Freq[0] = disting_freq * Index[1] / 1024;
				Basic_Freq[1] = disting_freq * Index[0] / 1024;
			}
		}
	}
	else
	{
		if(Index[1] * 3 != Index[0]) //no cover
		{
			Second_Amp = Mag[Index[1]];
			Three_Second_Amp = Mag[ Max_Float_WithinRange(Mag, 3*Index[1] - 3, 3*Index[1] + 3) ];
			Second_d = Second_Amp / Three_Second_Amp;
			
			if(Second_d < 20.0f) //have tri
			{
				Wave_Type[0] = 1;
				Wave_Type[1] = 1;
				Basic_Freq[0] = disting_freq * Index[1] / 1024;
				Basic_Freq[1] = disting_freq * Index[0] / 1024;
				
				if(Index[0] >= 159 && Index[0] <= 161 && Max_d > 25.0f)
				{
					Wave_Type[0] = 1;
					Wave_Type[1] = 0;
					Basic_Freq[0] = disting_freq * Index[1] / 1024;
					Basic_Freq[1] = disting_freq * Index[0] / 1024;
				}
			}
			else
			{
				Wave_Type[0] = 0;
				Wave_Type[1] = 1;
				Basic_Freq[0] = disting_freq * Index[1] / 1024;
				Basic_Freq[1] = disting_freq * Index[0] / 1024;
			}
		}
		else
		{
			Second_Amp = Mag[Index[1]];
			Five_Second_Amp = Mag[ Max_Float_WithinRange(Mag, 5*Index[1] - 3, 5*Index[1] + 3) ];
			Second_d = Second_Amp / Five_Second_Amp;
			
			if(Second_d < 40.0f) //have tri
			{
				Wave_Type[0] = 1;
				Wave_Type[1] = 1;
				Basic_Freq[0] = disting_freq * Index[1] / 1024;
				Basic_Freq[1] = disting_freq * Index[0] / 1024;
			}
			else
			{
				Wave_Type[0] = 0;
				Wave_Type[1] = 1;
				Basic_Freq[0] = disting_freq * Index[1] / 1024;
				Basic_Freq[1] = disting_freq * Index[0] / 1024;
			}
		}
	}
	
	if(Basic_Freq[0]>160000)
	{
		Basic_Freq[0]+=625;
	}
	if(Basic_Freq[1]>160000)
	{
		Basic_Freq[1]+=625;
	}
}

void Max_SecondMax_Index(float Mag[], u16 index[], u16 ignore_DC, u16 len)
{
	u16 i, max_index, seconde_index;
	
    if(ignore_DC)
	{
		max_index = 1;
		seconde_index = 1;
		i = 2;
	}
	else
	{
		max_index = 0;
		seconde_index = 0;
		i = 1;
	}
	
	for(; i < len; i++)
	{
		if(Mag[i] > Mag[max_index])
		{
			seconde_index = max_index;
			max_index = i;
		}
		else if(Mag[i] > Mag[seconde_index])
		{
			seconde_index = i;
		}
	}
	
	index[0] = max_index;
	index[1] = seconde_index;
}










