#include "stm32f4xx.h"                  // Device header
#include "adc.h"
#include "pid_phase.h"
#include "math.h"
#include "usart.h"
#include "ADS8688.h"
#include "stdlib.h"
#include "delay.h"
#include "AD9833.h"
#include "calculate.h"

	

#define find_range 9
#define find_times 3

double judge1=0;
double judge2=0;

	
extern	u32 Basic_Freq[2];
extern	u16 Wave_Type[2];






void get_phaseV(float * vot, uint8_t chnum, u8 times)
{
	u8 i=0;
	u32 t[2]={0};
	u16 v[2]={0};
	for(i=0;i<times;i++)
	{
		delay_ms(1);
		Get_AUTO_RST_Mode_Data(v, chnum);
		t[0]+=v[0];
		t[1]+=v[1];
	}
	t[0]/=times;
	t[1]/=times;

	vot[0] = (float)(((float)t[0]-32767.0f)/32767.0f*5120.0f);
	vot[1] = (float)(((float)t[1]-32767.0f)/32767.0f*5120.0f);
}
	


/*
	times--ȡ����б��
	sample_num--ÿ����ɼ�����Ϊ��ǰ��ѹֵ
	delay_time--б�ʵ�ʱ�� //��ʼ���Դ�һ�㣬���о�
*/

u32 get_deltV(u8 times,u8 sample_num,u8 delay_time)
{
	u16 i=0,j=0;
//	u16 value[sample_num]={0};
	u16 value = 0;
	long int first_error = 0, second_error = 0;
	u32 error = 0;
	u32 min_err0r=10000;
	u32 temp;
	for(j=0; j<times; j++)
	{
//		v_phase=abs(Get_AUTO_RST_Mode_Data(0)-Get_AUTO_RST_Mode_Data(0));
		
/*	ÿ��ȡ��ǰһ����ͺ�һ���㣬�����ֵ��б��		*/
		
		for(i=0; i < sample_num; i++)
		{
			Get_AUTO_RST_Mode_Data(& value, 1);
//			printf("%d\r\n",value);
			first_error += value;
		}	
			first_error/=sample_num;
		delay_ms(delay_time);
		
		for(i=0; i < sample_num; i++)
		{
			Get_AUTO_RST_Mode_Data(& value, 1);
			second_error += value;
		}	
			second_error/=sample_num;
		
/*	ÿ��ȡ��ǰһ����ͺ�һ���㣬�����ֵ��б��		*/
		temp=abs(first_error-second_error);
		
		if (temp<min_err0r)
			min_err0r=temp;
		error += temp;

	}
		error = (error) / (times);
	
//		printf("error: %d\r\n", error);
	
		return error;  
}








