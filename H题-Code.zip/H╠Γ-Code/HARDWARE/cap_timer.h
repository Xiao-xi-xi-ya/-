#ifndef __CAP_TIMER_H
#define __CAP_TIMER_H
#include "sys.h"



//void TIM5_CH2_Cap_Init(u32 arr,u16 psc);
void TIM4_Cnt_Init(void);
void TIM7_Int_Init(u16 arr,u16 psc);

#endif


