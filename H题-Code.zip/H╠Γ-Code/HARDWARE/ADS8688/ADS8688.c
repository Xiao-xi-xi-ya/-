
#include "stm32f4xx.h"                  // Device header
#include "ADS8688.h"



//Command Register 
#define NO_OP		0X0000//datasheet P43."Table 6. Command Register Map"
#define STDBY		0X8200//datasheet P43."Table 6. Command Register Map"
#define PWR_DN  	0X8300//datasheet P43."Table 6. Command Register Map"
#define RST	        0X8500//datasheet P43."Table 6. Command Register Map"
#define AUTO_RST	0XA000//datasheet P43."Table 6. Command Register Map"
#define MAN_Ch_0	0XC000//datasheet P43."Table 6. Command Register Map"
#define MAN_Ch_1	0XC400//datasheet P43."Table 6. Command Register Map"
#define MAN_Ch_2	0XC800//datasheet P43."Table 6. Command Register Map"
#define MAN_Ch_3	0XCC00//datasheet P43."Table 6. Command Register Map"
#define MAN_Ch_4	0XD000//datasheet P43."Table 6. Command Register Map"
#define MAN_Ch_5	0XD400//datasheet P43."Table 6. Command Register Map"
#define MAN_Ch_6	0XD800//datasheet P43."Table 6. Command Register Map"
#define MAN_Ch_7	0XDC00//datasheet P43."Table 6. Command Register Map"
#define MAN_AUX		0XE000//datasheet P43."Table 6. Command Register Map"



uint8_t test;
//uint16_t value[8];





void ads8688_set(void)//8ͨ���Զ�ɨ��ת��ʾ��
{
//�ǵÿ���d��û�п�ʱ��
  GPIO_Configuration();
  
  
  RST_PD_H;
  DAISY_IN_L;
  Delay(0x1fff);
  test=ADS8688A_INIT();
  Delay(0x1fff);
  
//  ADS8688A_Write_Program_Register(0x02,0x00);//����ͨ���˳��͹���״̬		//0x01		ͨ��0
//  ADS8688A_Write_Program_Register(0x01,0xff);//ʹ������ͨ��			//FFΪȫ1  0x01,0x01��ʹ��ͨ��0
  
	//ֻʹ����һ��
	ADS8688A_Write_Program_Register(0x02,0xfc);		//�����Ĳ��رգ�����
	ADS8688A_Write_Program_Register(0x01,0x03);		//ʹ��ͨ��0��1	
	
  Set_CH_Range_Select(0X05,0x01);//����ͨ��0�����뷶Χ����2.5*Vref
	Set_CH_Range_Select(0X06,0x01);
//	Set_CH_Range_Select(0X07,0x00);
	
	//ADS8688A_Write_Program_Register(0xa0,0x03);//��������
	
//  Set_CH_Range_Select(0X06,0x03);//����ͨ��1�����뷶Χ��0.625*Vref
//  Set_CH_Range_Select(0X07,0x03);//����ͨ��2�����뷶Χ��0.625*Vref
//  Set_CH_Range_Select(0X08,0x03);//����ͨ��3�����뷶Χ��0.625*Vref
//  Set_CH_Range_Select(0X09,0x02);//����ͨ��4�����뷶Χ��0.625*Vref
//  Set_CH_Range_Select(0X0a,0x02);//����ͨ��5�����뷶Χ��0.625*Vref
//  Set_CH_Range_Select(0X0b,0x02);//����ͨ��6�����뷶Χ��0.625*Vref
//  Set_CH_Range_Select(0X0c,0x02);//����ͨ��7�����뷶Χ��0.625*Vref
	
  //0x00 -> +-2.5*ref
  //0x01 -> +-1.25*ref
  //0x02 -> +-0.625*ref
  //0x03 -> +-0.3125*ref
  //0x0B -> +-0.15625*ref
  //0x05 -> +2.5*ref
  //0x06 -> +1.25*ref
  //0x07 -> +0.625*ref
  //0x0F -> +0.3125*ref
  
  AUTO_RST_Mode();//�����Զ�ɨ��ģʽ

}


/*
int main(void)//��ȡ��ͨ������ʾ��
{
  RCC_Configuration();
  GPIO_Configuration();
  NVIC_Configuration();
  
  RST_PD_H;
  DAISY_IN_L;
  Delay(0x1fff);
  test=ADS8688_INIT();
  Delay(0x1fff);
  
  ADS8688_Write_Program_Register(0x02,0x00);//����ͨ���˳��͹���״̬
  ADS8688_Write_Program_Register(0x01,0xff);//ʹ������ͨ��
  Set_CH_Range_Select(0X05,0x00);//����ͨ��0�����뷶Χ��2.5*Vref
  MAN_Ch_n_Mode(MAN_Ch_0);
  while(1)
  {
    value[0]=Get_MAN_Ch_n_Mode_Data();//��ȡ0ͨ�����ݣ���ӦӲ��ͨ����CH1
  }
}
*/


/*
int main(void)//��ȡ����ͨ�����ݣ���AUXͨ������ͨ��Ϊֱ��������ADC����PGA�����뷶ΧΪ0-4.096V��
{
  RCC_Configuration();
  GPIO_Configuration();
  NVIC_Configuration();
  
  RST_PD_H;
  DAISY_IN_L;
  Delay(0x1fff);
  test=ADS8688_INIT();
  Delay(0x1fff);
  
  MAN_Ch_n_Mode(MAN_AUX);
  while(1)
  {
    value[0]=Get_MAN_Ch_n_Mode_Data();//��ȡ����ͨ������
  }
}

*/


void AUTO_RST_Mode(void)//�����Զ�ɨ��ģʽ
{
  ADS8688A_WriteCommandReg(AUTO_RST);
}


////void Get_AUTO_RST_Mode_Data(uint16_t* outputdata, uint8_t chnum)
//u16 Get_AUTO_RST_Mode_Data(uint8_t chnum)
//{
//  //��ȡɨ��ͨ�����е�ADת������code������������
//  u8 i=0,datal=0,datah=0;
//  u16 data=0;
//  for (i=0; i<chnum; i++)
//  {
//    nCS_L;
//    ADS8688A_SPI_WB(0X00);
//    ADS8688A_SPI_WB(0X00);
//    datah = ADS8688A_SPI_RB();
//    datal = ADS8688A_SPI_RB();
//    nCS_H;
//    data = datah<<8 | datal;	//��λ��ǰ����λ�ں�
//   // *(outputdata+i) = data;
//		
//  }
//	return data;
//}

void Get_AUTO_RST_Mode_Data(uint16_t* outputdata, uint8_t chnum)
{
  //��ȡɨ��ͨ�����е�ADת������code������������
  u8 i=0,datal=0,datah=0;
  u16 data=0;
  for (i=0; i<chnum; i++)
  {
    nCS_L;
    ADS8688A_SPI_WB(0X00);
    ADS8688A_SPI_WB(0X00);
    datah = ADS8688A_SPI_RB();;
    datal = ADS8688A_SPI_RB();;
    nCS_H;
    data = datah<<8 | datal;	//��λ��ǰ����λ�ں�
    *(outputdata+i) = data;
  }
}

uint16_t Get_MAN_Ch_n_Mode_Data(void)
{
  u8 datah=0,datal=0;
  nCS_L;
  ADS8688A_SPI_WB(0X00);
  ADS8688A_SPI_WB(0X00);
  datah = ADS8688A_SPI_RB();
  datal = ADS8688A_SPI_RB();
  nCS_H;
  return (datah<<8 | datal);
}

void MAN_Ch_n_Mode(uint16_t ch)//�ֶ�ģʽ
{
  ADS8688A_WriteCommandReg(ch);	
}


void ADS8688A_Write_Program_Register(uint8_t Addr,uint8_t data)
{
  nCS_L;
  ADS8688A_SPI_WB(Addr<<1| 0X01);
  ADS8688A_SPI_WB(data);
  nCS_H;
}

void Set_CH_Range_Select(uint8_t ch,uint8_t range) //���ø���ͨ���ķ�Χ
{
  ADS8688A_Write_Program_Register(ch,range);
}



u8 ADS8688A_READ_Program_Register(uint8_t Addr)
{
  u8 data = 0;
  nCS_L;
  ADS8688A_SPI_WB(Addr<<1);
  data = ADS8688A_SPI_RB();
  data = ADS8688A_SPI_RB();
  nCS_H;
  return data;
}

void Enter_RESET_MODE(void)//������λģʽ����λ program registers
{
  ADS8688A_WriteCommandReg(RST);
}

void ADS8688A_WriteCommandReg(uint16_t command)//дADS8688����Ĵ���
{
  nCS_L;
  ADS8688A_SPI_WB(command>>8 & 0XFF);
  ADS8688A_SPI_WB(command & 0XFF);
  nCS_H;
}

uint8_t ADS8688A_INIT(void)
{
  uint8_t i;
//	RST_PD_H;
//  DAISY_IN_L;
  Delay(0x1fff);
	
  Enter_RESET_MODE();
  ADS8688A_Write_Program_Register(0X01,0XFF);
  i = ADS8688A_READ_Program_Register(0X01);
  return i;
}


uint8_t ADS8688A_SPI_RB(void)
{
  uint8_t Rdata=0,s;
  //nCS_L;
  for(s=0;s<8;s++)
  {
    Rdata<<=1;
    SCLK_H;
    if(SDO)
    {
      Rdata|=0x01;
    }
    else
    {
      Rdata&=0xFE;
    }
    SCLK_L;
  }
  return Rdata;
}


void ADS8688A_SPI_WB(uint8_t com)
{
  uint8_t com_temp=com,s;
  nCS_L;
  for( s=0;s<8;s++)
  {
    if(com_temp&0x80)
    {
      SDI_H;
    }
    else
    {
      SDI_L;
    }
    SCLK_H;
    com_temp<<=1;
    SCLK_L;
  }
}



//void RCC_Configuration(void)
//{
//  ErrorStatus HSEStartUpStatus;
//  RCC_DeInit();
//  RCC_HSEConfig(RCC_HSE_ON);
//  HSEStartUpStatus=RCC_WaitForHSEStartUp();
//  if(HSEStartUpStatus==SUCCESS)
//  {
//    RCC_HCLKConfig(RCC_SYSCLK_Div1);
//    RCC_PCLK2Config(RCC_HCLK_Div1);
//    RCC_PCLK1Config(RCC_HCLK_Div2);
//    FLASH_SetLatency(FLASH_Latency_2);
//    FLASH_PrefetchBufferCmd(FLASH_PrefetchBuffer_Enable);
//    RCC_PLLConfig(RCC_PLLSource_HSE_Div1,RCC_PLLMul_9);
//    RCC_PLLCmd(ENABLE);
//    while(RCC_GetFlagStatus(RCC_FLAG_PLLRDY)==RESET);
//    RCC_SYSCLKConfig(RCC_SYSCLKSource_PLLCLK);
//   while(RCC_GetSYSCLKSource()!=0x08);
//  }
//  RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOD|RCC_APB2Periph_GPIOG,ENABLE);
//}



void Delay(uint32_t nCount)
{
  for(; nCount != 0; nCount--);
}



//void NVIC_Configuration(void)
//{
//  NVIC_InitTypeDef NVIC_InitStructure;
//#ifdef VECT_TAB_RAM
//  NVIC_SetVectorTable(NVIC_VectTab_RAM,0x0);
//#else
//  NVIC_SetVectorTable(NVIC_VectTab_FLASH,0x0);
//#endif
//  NVIC_PriorityGroupConfig(NVIC_PriorityGroup_0);
//  NVIC_InitStructure.NVIC_IRQChannel=TIM1_UP_IRQn;
//  NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority=0;
//  NVIC_InitStructure.NVIC_IRQChannelSubPriority=0;
//  NVIC_InitStructure.NVIC_IRQChannelCmd=ENABLE;
//  NVIC_Init(&NVIC_InitStructure);
////CAN�����жϳ�ʼ��
//  NVIC_InitStructure.NVIC_IRQChannel = USB_LP_CAN1_RX0_IRQn;
//  NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 0;
//  NVIC_InitStructure.NVIC_IRQChannelSubPriority = 1;
//  NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
//  NVIC_Init(&NVIC_InitStructure);
//  /* Enable the USART1 Interrupt */
//  NVIC_InitStructure.NVIC_IRQChannel = USART1_IRQn;
//  NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 0;
//  NVIC_InitStructure.NVIC_IRQChannelSubPriority = 2;
//  NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
//  NVIC_Init(&NVIC_InitStructure);
//}


void GPIO_Configuration(void)
{
	
  GPIO_InitTypeDef GPIO_InitStructure;
	RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOD,ENABLE); //ʹ��GPIOAʱ�ӣ��޸�
  /***********************************************************************///ADC INTERFACE
  //GPIO_InitStructure.GPIO_Pin = GPIO_Pin_9|GPIO_Pin_10|GPIO_Pin_11|GPIO_Pin_12|GPIO_Pin_13|GPIO_Pin_14|GPIO_Pin_15;
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_0|GPIO_Pin_1|GPIO_Pin_2|GPIO_Pin_3|GPIO_Pin_4;
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_OUT ;
	GPIO_InitStructure.GPIO_OType = GPIO_OType_PP;
  GPIO_InitStructure.GPIO_Speed = GPIO_Speed_100MHz; 
  GPIO_Init(GPIOD, &GPIO_InitStructure);
//  GPIO_InitStructure.GPIO_Pin = GPIO_Pin_8;//SDO
	  GPIO_InitStructure.GPIO_Pin = GPIO_Pin_5;//SDO
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN ;
	GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_NOPULL;
  GPIO_InitStructure.GPIO_Speed = GPIO_Speed_100MHz; 
  GPIO_Init(GPIOD, &GPIO_InitStructure);
}


