#ifndef __ADS8688_H
#define __ADS8688_H 			   
#include <sys.h>	  

void ads8688_set(void);
void GPIO_Configuration(void);
void Delay(uint32_t nCount);
void ADS8688A_SPI_WB(uint8_t com);
uint8_t ADS8688A_SPI_RB(void);
uint8_t ADS8688A_INIT(void);
void ADS8688A_WriteCommandReg(uint16_t command);//дADS8688����Ĵ���
u16 Get_MAN_Ch_n_Mode_Data(void);
void MAN_Ch_n_Mode(uint16_t ch);//ѡ������ͨ��
void Set_CH_Range_Select(uint8_t ch,uint8_t range); //���ø���ͨ���ķ�Χ
//u16 Get_AUTO_RST_Mode_Data( uint8_t chnum);
void ADS8688A_Write_Program_Register(uint8_t Addr,uint8_t data);
void AUTO_RST_Mode(void);


void Get_AUTO_RST_Mode_Data(uint16_t* outputdata, uint8_t chnum);

//#define DAISY_IN_H GPIO_SetBits(GPIOD,GPIO_Pin_9)
//#define DAISY_IN_L GPIO_ResetBits(GPIOD,GPIO_Pin_9)

//#define SCLK_H GPIO_SetBits(GPIOD,GPIO_Pin_10)
//#define SCLK_L GPIO_ResetBits(GPIOD,GPIO_Pin_10)

//#define nCS_H GPIO_SetBits(GPIOD,GPIO_Pin_11)
//#define nCS_L GPIO_ResetBits(GPIOD,GPIO_Pin_11)

//#define RST_PD_H GPIO_SetBits(GPIOD,GPIO_Pin_13)
//#define RST_PD_L GPIO_ResetBits(GPIOD,GPIO_Pin_13)

//#define SDI_H GPIO_SetBits(GPIOD,GPIO_Pin_15)
//#define SDI_L GPIO_ResetBits(GPIOD,GPIO_Pin_15)

//#define SDO GPIO_ReadInputDataBit(GPIOD,GPIO_Pin_8)
/*
		�޸ĺ�û�ù�
*/
#define DAISY_IN_H GPIO_SetBits(GPIOD,GPIO_Pin_0)
#define DAISY_IN_L GPIO_ResetBits(GPIOD,GPIO_Pin_0)

#define SCLK_H GPIO_SetBits(GPIOD,GPIO_Pin_1)
#define SCLK_L GPIO_ResetBits(GPIOD,GPIO_Pin_1)

#define nCS_H GPIO_SetBits(GPIOD,GPIO_Pin_2)
#define nCS_L GPIO_ResetBits(GPIOD,GPIO_Pin_2)

#define RST_PD_H GPIO_SetBits(GPIOD,GPIO_Pin_3)
#define RST_PD_L GPIO_ResetBits(GPIOD,GPIO_Pin_3)

#define SDI_H GPIO_SetBits(GPIOD,GPIO_Pin_4)
#define SDI_L GPIO_ResetBits(GPIOD,GPIO_Pin_4)

#define SDO GPIO_ReadInputDataBit(GPIOD,GPIO_Pin_5)

#endif
