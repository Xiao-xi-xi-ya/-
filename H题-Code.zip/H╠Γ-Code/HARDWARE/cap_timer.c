#include "stm32f4xx.h"                  // Device header

#include "cap_timer.h"
#include "usart.h"
#include "led.h"

#include "ADS8688.h"
/*
tim5 -- 1MHz

*/
TIM_ICInitTypeDef  TIM5_ICInitStructure;



void TIM7_Int_Init(u16 arr,u16 psc)
{
	TIM_TimeBaseInitTypeDef TIM_TimeBaseInitStructure;
	NVIC_InitTypeDef NVIC_InitStructure;
	
	RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM7,ENABLE);  ///ʹ��TIM3ʱ��
	
  TIM_TimeBaseInitStructure.TIM_Period = arr; 	//�Զ���װ��ֵ
	TIM_TimeBaseInitStructure.TIM_Prescaler=psc;  //��ʱ����Ƶ
	TIM_TimeBaseInitStructure.TIM_CounterMode=TIM_CounterMode_Up; //���ϼ���ģʽ
	TIM_TimeBaseInitStructure.TIM_ClockDivision=TIM_CKD_DIV1; 
	
	TIM_TimeBaseInit(TIM7,&TIM_TimeBaseInitStructure);//��ʼ��TIM3
	
	TIM_ITConfig(TIM7,TIM_IT_Update,ENABLE); //������ʱ��3�����ж�
	TIM_Cmd(TIM7,ENABLE); //ʹ�ܶ�ʱ��3
	
	NVIC_InitStructure.NVIC_IRQChannel=TIM7_IRQn; //��ʱ��3�ж�
	NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority=0x01; //��ռ���ȼ�1
	NVIC_InitStructure.NVIC_IRQChannelSubPriority=0x03; //�����ȼ�3
	NVIC_InitStructure.NVIC_IRQChannelCmd=ENABLE;
	NVIC_Init(&NVIC_InitStructure);
	
}

//��ʱ��7�жϷ�����

u32 TIM7_LastCnt;
u32 TIM_ExtCntFreq;
extern	u8 flag_90[2];
u8 flag_led=0;
extern u8 flag_200ms;

uint16_t v_suoxiang[2];
void TIM7_IRQHandler(void)
{
	if(TIM_GetITStatus(TIM7,TIM_IT_Update)==SET) //����ж�
	{
		LED0=!LED0;//D2��ת
		if(flag_200ms==0)
		{
			flag_200ms=1;
				if(flag_90[0]==1 && flag_90[1]==1)
					Get_AUTO_RST_Mode_Data(v_suoxiang,2);		
		}
		
	}
	TIM_ClearITPendingBit(TIM7,TIM_IT_Update);  //����жϱ�־λ
}




void TIM4_Cnt_Init(void)
{
     

	GPIO_InitTypeDef GPIO_InitStructure;
    TIM_TimeBaseInitTypeDef TIM_TimeBaseStructure;
    RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM4,ENABLE);  // ʹ��TIM4ʱ��
	RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOE, ENABLE);  // ʹ��GPIOEE

	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_0;  // PE0
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF;  // ��������
	GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_UP;  // ����
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_100MHz;
	GPIO_Init(GPIOE,&GPIO_InitStructure);

	GPIO_PinAFConfig(GPIOE, GPIO_PinSource0, GPIO_AF_TIM4);  // ����TIM4

	TIM_TimeBaseStructure.TIM_Period = 0xFFFFFFFF;  // ��װֵ
	TIM_TimeBaseStructure.TIM_Prescaler = 10-1;   // ��Ƶϵ��0
	TIM_TimeBaseStructure.TIM_ClockDivision = TIM_CKD_DIV1; 
	TIM_TimeBaseStructure.TIM_CounterMode = TIM_CounterMode_Up;  // ���ϼ���
	TIM_TimeBaseInit(TIM4, &TIM_TimeBaseStructure);

	TIM_ETRClockMode2Config(TIM4, TIM_ExtTRGPSC_OFF, TIM_ExtTRGPolarity_NonInverted, 0);  //�ⲿʱ��Դģʽ2
	TIM_SetCounter(TIM4, 0);
	TIM_ITConfig(TIM4,TIM_IT_Update,ENABLE);
	//TIM_Cmd(TIM4, ENABLE);
}





