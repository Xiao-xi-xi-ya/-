#include "dac_wave.h"

/*
PA4 ΪDAC_OUT1
PA5 ΪDAC_OUT2

*/


/*
*********************************************************************************************************
*	�� �� ��: bsp_InitDAC1
*	����˵��: ����PA4/DAC1
*	��    ��: ��
*	�� �� ֵ: ��
*********************************************************************************************************
*/

#define low_num 72
#define high_num 84

/*  ���Ҳ����ݣ�12bit��1������128����, 0-4095֮��仯 */
u16 g_Wave1_128[high_num];
u16 g_Wave1_42[low_num];

u16 g_Wave2_128[high_num*2];
u16 g_Wave2_42[low_num*2];



u8 flag50_128=0;

/*	0-314	*/
u16 deltaP=0;
const uint16_t g_SineWave128[] = {
2048,2201,2353,2504,2651,2796,2936,3072,3201,3324,3440,3549,3648,3739,3821,3892,3953,4004,4044,4072,4089,4095,4089,4072,4044,4004,3953,3892,3821,3739,3648,3549,3440,3324,3201,3072,2936,2796,2651,2504,2353,2201,2048,1895,1743,1592,
	1445,1300,1160,1025,895,772,656,547,448,357,275,204,143,92,52,24,7,1,7,24,52,92,143,204,275,357,448,547,656,772,895,1024,1160,1300,1445,1592,1743,1895

};
const uint16_t g_SineWave42[] = {

1,115,228,342,456,570,683,797,911,1025,1138,1252,1366,1479,1593,1707,1821,1934,2048,2162,2275,2389,2503,2617,2730,2844,2958,3072,3185,3299,3413,3526,3640,3754,3868,3981,4095,3981,3868,3754,3640,3526,3413,3299,
	3185,3072,2958,2844,2730,2617,2503,2389,2275,2162,2048,1934,1821,1707,1593,1479,1366,1252,1138,1025,911,797,683,570,456,342,228,115
};
const uint16_t g_TriWave128[] = {

1,98,196,293,391,488,586,683,781,878,976,1073,1171,1268,1366,1463,1561,1658,1756,1853,1951,2048,2145,2243,2340,2438,2535,2633,2730,2828,2925,3023,3120,3218,3315,3413,3510,3608,3705,3803,3900,3998,4095,3998,3900,3803,3705,3608,3510,3413,3315,3218,3120,
	3023,2925,2828,2730,2633,2535,2438,2340,2243,2145,2048,1951,1853,1756,1658,1561,1463,1366,1268,1171,1073,976,878,781,683,586,488,391,293,196,98
};


const uint16_t g_TriWave42[]=
{
1,115,228,342,456,570,683,797,911,1025,1138,1252,1366,1479,1593,1707,1821,1934,2048,2162,2275,2389,2503,2617,2730,2844,2958,3072,3185,3299,3413,3526,3640,3754,3868,3981,4095,3981,3868,3754,3640,3526,3413,3299,3185,3072,2958,2844,2730,
	2617,2503,2389,2275,2162,2048,1934,1821,1707,1593,1479,1366,1252,1138,1025,911,797,683,570,456,342,228,115
};


void bsp_InitDAC1(void)
{	
	/* ����GPIO */
	{
		GPIO_InitTypeDef GPIO_InitStructure;
		
		RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOA, ENABLE);
		
		/* ����DAC����Ϊģ��ģʽ  PA4 / DAC_OUT1 */
		GPIO_InitStructure.GPIO_Pin = GPIO_Pin_4|GPIO_Pin_5;
		GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AN;
		GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_NOPULL ;
		GPIO_Init(GPIOA, &GPIO_InitStructure);
	}	

	/* DACͨ��1���� */
	{
		DAC_InitTypeDef DAC_InitStructure;
		
		/* ʹ��DACʱ�� */
		RCC_APB1PeriphClockCmd(RCC_APB1Periph_DAC, ENABLE);		

		DAC_InitStructure.DAC_Trigger = DAC_Trigger_None;	/* ѡ����������, �����޸�DAC���ݼĴ��� */
		DAC_InitStructure.DAC_WaveGeneration = DAC_WaveGeneration_None;
		DAC_InitStructure.DAC_LFSRUnmask_TriangleAmplitude = DAC_LFSRUnmask_Bit0;
		//DAC_InitStructure.DAC_OutputBuffer = DAC_OutputBuffer_Enable;
		DAC_InitStructure.DAC_OutputBuffer = DAC_OutputBuffer_Disable;
		DAC_Init(DAC_Channel_1, &DAC_InitStructure);
		DAC_Cmd(DAC_Channel_1, ENABLE);
		DAC_Init(DAC_Channel_2, &DAC_InitStructure);
		DAC_Cmd(DAC_Channel_2, ENABLE);
	}
}

/*
*********************************************************************************************************
*	�� �� ��: dac1_InitForDMA
*	����˵��: ����PA4 ΪDAC_OUT1, ����DMA2
*	��    ��: _BufAddr : DMA���ݻ�������ַ
*			  _Count   : ��������������
*			 _DacFreq  : DAC��������Ƶ��
*	�� �� ֵ: ��
*********************************************************************************************************
*/




void dac1_InitForDMA(uint32_t _BufAddr, uint32_t _Count, uint32_t _DacFreq)
{	
	uint32_t usPeriod;
	uint32_t usPrescaler;
	uint32_t uiTIMxCLK;
	TIM_TimeBaseInitTypeDef  TIM_TimeBaseStructure;
	
	DMA_Cmd(DMA1_Stream5, DISABLE);
	DAC_DMACmd(DAC_Channel_1, DISABLE);
	TIM_Cmd(TIM6, DISABLE);

	/* TIM6���� */
	{
		RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM6, ENABLE);
		
		uiTIMxCLK = SystemCoreClock / 2;
		
		if (_DacFreq < 100)
		{
			usPrescaler = 10000 - 1;						 /* ��Ƶ�� = 10000 */
			usPeriod =  (uiTIMxCLK / 10000) / _DacFreq  - 1; /* �Զ���װ��ֵ */
		}
		else if (_DacFreq < 3000)
		{
			usPrescaler = 100 - 1;							/* ��Ƶ�� = 100 */
			usPeriod =  (uiTIMxCLK / 100) / _DacFreq  - 1;	/* �Զ���װ��ֵ */
		}
		else	/* ����4K��Ƶ�ʣ������Ƶ */
		{
			usPrescaler = 0;						/* ��Ƶ�� = 1 */
			usPeriod = uiTIMxCLK / _DacFreq - 1;	/* �Զ���װ��ֵ */
		}

		TIM_TimeBaseStructure.TIM_Period = usPeriod;
		TIM_TimeBaseStructure.TIM_Prescaler = usPrescaler;
		TIM_TimeBaseStructure.TIM_ClockDivision = 0;
		TIM_TimeBaseStructure.TIM_CounterMode = TIM_CounterMode_Up;
		TIM_TimeBaseStructure.TIM_RepetitionCounter = 0x0000;		/* TIM1 �� TIM8 �������� */	

		TIM_TimeBaseInit(TIM6, &TIM_TimeBaseStructure);

		/* ѡ��TIM6��DAC�Ĵ���ʱ�� */
		TIM_SelectOutputTrigger(TIM6, TIM_TRGOSource_Update);

		
	}

	/* DACͨ��1���� */
	{
		DAC_InitTypeDef DAC_InitStructure;
		
		/* ʹ��DACʱ�� */
		RCC_APB1PeriphClockCmd(RCC_APB1Periph_DAC, ENABLE);		

		DAC_InitStructure.DAC_Trigger = DAC_Trigger_T6_TRGO;
		DAC_InitStructure.DAC_WaveGeneration = DAC_WaveGeneration_None;
		DAC_InitStructure.DAC_LFSRUnmask_TriangleAmplitude = DAC_LFSRUnmask_Bit0;
		//DAC_InitStructure.DAC_OutputBuffer = DAC_OutputBuffer_Enable;
		DAC_InitStructure.DAC_OutputBuffer = DAC_OutputBuffer_Disable;
		DAC_Init(DAC_Channel_1, &DAC_InitStructure);
		DAC_Cmd(DAC_Channel_1, ENABLE);
	}

	/* DMA1_Stream5���� */
	{
		DMA_InitTypeDef DMA_InitStructure;

		RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_DMA1, ENABLE);

		/* ����DMA1 Stream 5 channel 7����DAC1 */
		DMA_InitStructure.DMA_Channel = DMA_Channel_7;
		DMA_InitStructure.DMA_PeripheralBaseAddr = (uint32_t)&DAC->DHR12R1; 
		DMA_InitStructure.DMA_Memory0BaseAddr = _BufAddr;	
		DMA_InitStructure.DMA_DIR = DMA_DIR_MemoryToPeripheral;		
		DMA_InitStructure.DMA_BufferSize = _Count;
		DMA_InitStructure.DMA_PeripheralInc = DMA_PeripheralInc_Disable;
		DMA_InitStructure.DMA_MemoryInc = DMA_MemoryInc_Enable;
		DMA_InitStructure.DMA_PeripheralDataSize = DMA_PeripheralDataSize_HalfWord;
		DMA_InitStructure.DMA_MemoryDataSize = DMA_PeripheralDataSize_HalfWord;
		DMA_InitStructure.DMA_Mode = DMA_Mode_Circular;								//ѭ��ģʽ
		DMA_InitStructure.DMA_Priority = DMA_Priority_High;
		DMA_InitStructure.DMA_FIFOMode = DMA_FIFOMode_Disable;
		DMA_InitStructure.DMA_FIFOThreshold = DMA_FIFOThreshold_HalfFull;
		DMA_InitStructure.DMA_MemoryBurst = DMA_MemoryBurst_Single;
		DMA_InitStructure.DMA_PeripheralBurst = DMA_PeripheralBurst_Single;
		DMA_Init(DMA1_Stream5, &DMA_InitStructure);
		DMA_Cmd(DMA1_Stream5, ENABLE);

		/* ʹ��DACͨ��1��DMA */
		DAC_DMACmd(DAC_Channel_1, ENABLE);
	}

	/* ʹ�ܶ�ʱ�� */
	//TIM_Cmd(TIM6, ENABLE);
	
}

void dac2_InitForDMA(uint32_t _BufAddr, uint32_t _Count, uint32_t _DacFreq)//����ʹ��Ĭ����1��
{	
	uint32_t usPeriod;
	uint32_t usPrescaler;
	uint32_t uiTIMxCLK;
	TIM_TimeBaseInitTypeDef  TIM_TimeBaseStructure;
	GPIO_InitTypeDef   GPIO_InitStructure;
	DMA_Cmd(DMA1_Stream6, DISABLE);
	DAC_DMACmd(DAC_Channel_2, DISABLE);
	//TIM_Cmd(TIM5, DISABLE);
	TIM_Cmd(TIM2, DISABLE);
	/* TIM5���� */
	{
		//RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM5, ENABLE);
		RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM2, ENABLE);


    RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM2,ENABLE);  // ʹ��TIM4ʱ��
	RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOA, ENABLE);  // ʹ��GPIOEE

	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_15;  // PE0
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF;  // ��������
	GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_UP;  // ����
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_100MHz;
	GPIO_Init(GPIOA,&GPIO_InitStructure);

	GPIO_PinAFConfig(GPIOA, GPIO_PinSource15, GPIO_AF_TIM2);  // ����TIM4
	TIM_DeInit(TIM2);
	TIM_TimeBaseStructure.TIM_Period = 2-1;  // ��װֵ
	TIM_TimeBaseStructure.TIM_Prescaler = 1-1;   // ��Ƶϵ��0
	TIM_TimeBaseStructure.TIM_ClockDivision = TIM_CKD_DIV1; 
	TIM_TimeBaseStructure.TIM_CounterMode = TIM_CounterMode_Up;  // ���ϼ���
	TIM_TimeBaseInit(TIM2, &TIM_TimeBaseStructure);

	TIM_SetCounter(TIM2, 0);
	TIM_ITConfig(TIM2,TIM_IT_Update,ENABLE);
	
	TIM_ITRxExternalClockConfig(TIM2,TIM_TS_ITR1);//�߼���ʱ������
	//TIM_TIxExternalClockConfig(TIM2,TIM_TIxExternalCLK1Source_TI1,TIM_ICPolarity_Falling,15);
	TIM_ETRClockMode2Config(TIM2, TIM_ExtTRGPSC_OFF, TIM_ExtTRGPolarity_NonInverted, 0);  //�ⲿʱ��Դģʽ2
	TIM_SetCounter( TIM2,0 );
	TIM_Cmd(TIM2, ENABLE);
	TIM_SelectOutputTrigger(TIM2, TIM_TRGOSource_Update);
		
		
		
		
		/* ѡ��TIM6��DAC�Ĵ���ʱ�� */
		//TIM_SelectOutputTrigger(TIM5, TIM_TRGOSource_Update);

		
	}

	/* DACͨ��1���� */
	{
		DAC_InitTypeDef DAC_InitStructure;
		

		DAC_InitStructure.DAC_Trigger = DAC_Trigger_T2_TRGO;//DAC_Trigger_T5_TRGO;
		DAC_InitStructure.DAC_WaveGeneration = DAC_WaveGeneration_None;
		DAC_InitStructure.DAC_LFSRUnmask_TriangleAmplitude = DAC_LFSRUnmask_Bit0;
		DAC_InitStructure.DAC_OutputBuffer = DAC_OutputBuffer_Enable;
		//DAC_InitStructure.DAC_OutputBuffer = DAC_OutputBuffer_Disable;
		DAC_Init(DAC_Channel_2, &DAC_InitStructure);
		DAC_Cmd(DAC_Channel_2, ENABLE);
	}

	/* DMA1_Stream5���� */
	{
		DMA_InitTypeDef DMA_InitStructure;


		/* ����DMA1 Stream 5 channel 7����DAC1 */
		DMA_InitStructure.DMA_Channel = DMA_Channel_7;
		DMA_InitStructure.DMA_PeripheralBaseAddr = (uint32_t)&DAC->DHR12R2; 
		DMA_InitStructure.DMA_Memory0BaseAddr = _BufAddr;	
		DMA_InitStructure.DMA_DIR = DMA_DIR_MemoryToPeripheral;		
		DMA_InitStructure.DMA_BufferSize = _Count;
		DMA_InitStructure.DMA_PeripheralInc = DMA_PeripheralInc_Disable;
		DMA_InitStructure.DMA_MemoryInc = DMA_MemoryInc_Enable;
		DMA_InitStructure.DMA_PeripheralDataSize = DMA_PeripheralDataSize_HalfWord;
		DMA_InitStructure.DMA_MemoryDataSize = DMA_PeripheralDataSize_HalfWord;
		DMA_InitStructure.DMA_Mode = DMA_Mode_Circular;								//ѭ��ģʽ
		DMA_InitStructure.DMA_Priority = DMA_Priority_High;
		DMA_InitStructure.DMA_FIFOMode = DMA_FIFOMode_Disable;
		DMA_InitStructure.DMA_FIFOThreshold = DMA_FIFOThreshold_HalfFull;
		DMA_InitStructure.DMA_MemoryBurst = DMA_MemoryBurst_Single;
		DMA_InitStructure.DMA_PeripheralBurst = DMA_PeripheralBurst_Single;
		DMA_Init(DMA1_Stream6, &DMA_InitStructure);
		DMA_Cmd(DMA1_Stream6, ENABLE);

		/* ʹ��DACͨ��1��DMA */
		DAC_DMACmd(DAC_Channel_2, ENABLE);
	}

	/* ʹ�ܶ�ʱ�� */
	//TIM_Cmd(TIM5, ENABLE);
	
}


/*
*********************************************************************************************************
*	�� �� ��: dac1_SetSinWave
*	����˵��: DAC1������Ҳ�
*	��    ��: _vpp : ���� 0-4095;
*			  _freq : Ƶ��
*	�� �� ֵ: ��
*********************************************************************************************************
*/
void dac1_SetSinWave(uint16_t _vpp, uint32_t _freq)
{	
	uint32_t i;
	uint32_t dac;
	
	TIM_Cmd(TIM6, DISABLE);
		
	/* �������Ҳ����� */	
	if(flag50_128==1)
	{	
		for (i = 0; i < high_num; i++)
		{
			dac = (g_SineWave128[i] * _vpp) / 4095+1000;
			if (dac > 4095)
			{
				dac = 4095;	
			}
			g_Wave1_128[i] = dac;
		}
		dac1_InitForDMA((uint32_t)&g_Wave1_128, high_num, _freq * high_num);
		return ;
	}
	else if (flag50_128==0)
	{
				for (i = 0; i < low_num; i++)
		{
			dac = (g_SineWave42[i] * _vpp) / 4095+1000;
			if (dac > 4095)
			{
				dac = 4095;	
			}
			g_Wave1_42[i] = dac;
		}
	}

	dac1_InitForDMA((uint32_t)&g_Wave1_42, low_num, _freq * low_num);

	
}

void dac2_SetSinWave(uint16_t _vpp, uint32_t _freq,u16 phase)
{	
	uint32_t i;
	uint32_t dac;
	
	TIM_Cmd(TIM2, DISABLE);
		
	/* �������Ҳ����� */	
	if(flag50_128==1)
	{	
		for (i = 0; i < high_num; i++)
		{
			dac = (g_SineWave128[i] * _vpp) / 4095+1000;
			if (dac > 4095)
			{
				dac = 4095;	
			}
			
			g_Wave2_128[i] = dac;
		}
				for (i = 0; i < high_num; i++)
		{
			dac = (g_SineWave128[i] * _vpp) / 4095+1000;
			if (dac > 4095)
			{
				dac = 4095;	
			}
			
			g_Wave2_128[high_num+i] = dac;
		}
		phase=(int)(phase*high_num/314);
		dac2_InitForDMA((uint32_t)&g_Wave2_128[phase], high_num, _freq * high_num);
		return ;
	}
	else if (flag50_128==0)
	{
				for (i = 0; i < low_num; i++)
		{
			dac = (g_SineWave42[i] * _vpp) / 4095+1000;
			if (dac > 4095)
			{
				dac = 4095;	
			}
			
			g_Wave2_42[i] = dac;
		}
		
						for (i = 0; i < low_num; i++)
		{
			dac = (g_SineWave42[i] * _vpp) / 4095+1000;
			if (dac > 4095)
			{
				dac = 4095;	
			}
			
			g_Wave2_42[low_num+i] = dac;
		}
		
		phase=(int)(phase*low_num/314);
	}

	dac2_InitForDMA((uint32_t)&g_Wave2_42[phase], low_num, _freq * low_num);

	
}



/*
*********************************************************************************************************
*	�� �� ��: dac1_SetTriWave
*	����˵��: DAC1������ǲ�
*	��    ��: _low : �͵�ƽʱDAC, 
*			  _high : �ߵ�ƽʱDAC
*			  _freq : Ƶ�� Hz
*			  _duty : ռ�ձ�
*	�� �� ֵ: ��
*********************************************************************************************************
*/
void dac1_SetTriWave(uint32_t _freq,uint16_t _vpp)
{	
	uint32_t i;
	uint16_t dac;
	//u32 g_Wave2[42];
	
	TIM_Cmd(TIM6, DISABLE);
		
	/* �������ǲ����飬128���������� _low �� _high */		
	if(flag50_128==1)
	{
			for (i = 0; i < high_num; i++)
		{
			dac = (g_TriWave128[i] * _vpp) / 4095;
			if (dac > 4095)
			{
				dac = 4095;	
			}
			g_Wave1_128[i] = dac;
		}
		dac1_InitForDMA((uint32_t)&g_Wave1_128, high_num, _freq * high_num);
		return ;
	}
	if(flag50_128==0)
	{
		for(i=0;i<low_num;i++)
		{
			g_Wave1_42[i]=g_TriWave42[i];
		}
		dac1_InitForDMA((uint32_t)&g_Wave1_42, low_num, _freq * low_num);
	
	}
	
	
	
}

void dac2_SetTriWave(uint16_t _vpp,uint32_t _freq)
{	
	uint32_t i;
	uint16_t dac;
	//u32 g_Wave2[42];
	
	TIM_Cmd(TIM2, DISABLE);
		
	/* �������ǲ����飬128���������� _low �� _high */		
	if(flag50_128==1)
	{
			for (i = 0; i < high_num; i++)
		{
			dac = (g_TriWave128[i] * _vpp) / 4095;
			if (dac > 4095)
			{
				dac = 4095;	
			}
			g_Wave2_128[i] = dac;
		}
		dac2_InitForDMA((uint32_t)&g_Wave2_128, high_num, _freq * high_num);
		return ;
	}
	if(flag50_128==0)
	{
		for(i=0;i<low_num;i++)
		{
			g_Wave2_42[i]=g_TriWave42[i];
		}
		dac2_InitForDMA((uint32_t)&g_Wave2_42, low_num, _freq * low_num);
	
	}
	
}



