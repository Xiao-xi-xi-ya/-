#ifndef __DAC_WAVE_H
#define __DAC_WAVE_H
#include "sys.h"

void dac1_InitForDMA(uint32_t _BufAddr, uint32_t _Count, uint32_t _DacFreq);
void bsp_InitDAC1(void);
void dac1_SetSinWave(uint16_t _vpp, uint32_t _freq);
void dac1_SetTriWave( uint32_t _freq,uint16_t _vpp);

void dac2_InitForDMA(uint32_t _BufAddr, uint32_t _Count, uint32_t _DacFreq);
void dac2_SetTriWave(uint16_t _vpp,uint32_t _freq);
void dac2_SetSinWave(uint16_t _vpp, uint32_t _freq,u16 phase);

#endif

